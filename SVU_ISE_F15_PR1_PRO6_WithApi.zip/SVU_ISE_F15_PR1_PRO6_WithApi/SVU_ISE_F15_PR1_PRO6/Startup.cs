﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SVU_ISE_F15_PR1_PRO6.Startup))]
namespace SVU_ISE_F15_PR1_PRO6
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
