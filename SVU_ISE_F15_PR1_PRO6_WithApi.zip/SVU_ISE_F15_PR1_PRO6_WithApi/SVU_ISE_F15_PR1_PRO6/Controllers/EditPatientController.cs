﻿
// using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.Mvc;
//using System.Data.Entity.Infrastructure;
//using System.Net;
//using System.Data;
//using System.ComponentModel.DataAnnotations;
//using System.Data.Entity;
//using System.Data.Entity.Core.Objects;

//namespace SVU_ISE_F15_PR1_PRO6.Controllers
//{
//    public class EditPatientController : Controller
//    {
//        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        
//        // GET: /EditPatient/
//        public ActionResult Index()
//        {
//            return View(db.EditPatientFile_Table.ToList());
//        }

        
//       //  GET: /EditPatient/Details/5
//        public ActionResult Details(int? dr_Id, int? p_Id)
//        {
//             EditPatientFile_Table edit = db.EditPatientFile_Table.Find(dr_Id, p_Id);
//            if (edit == null)
//            {
//                return HttpNotFound();
//            }
//            return View(edit);
//        }

        
//        // GET: /EditPatient/Create
//        public ActionResult Create()
//        {
//            PopulateDoctorsDropDownList();
//            PopulatePatientDropDownList();
//            return View();
//        }

        
//        // POST: /EditPatient/Create
//        [HttpPost]
//        public ActionResult Create(EditPatientFile_Table edit)
//        {
//            try
//            {
//                if (ModelState.IsValid)
//                {
//                   //  if primary key is exist
//                    if (Check(edit.dr_Id, edit.p_Id))
//                    {
//                        ModelState.AddModelError("", "The patient is alredy have this medication");
//                    }
//                     else
//                     {
//                         db.EditPatientFile_Table.Add(edit);
//                    db.SaveChanges();
//                    return RedirectToAction("Index");
//                      }

//                }
//            }
//            catch (RetryLimitExceededException)
//            {
//                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
//            }
//            PopulateDoctorsDropDownList(edit.dr_Id);
//            PopulatePatientDropDownList(edit.p_Id);

//            return View(edit);
//        }

        
//      //   GET: /EditPatient/Edit/5
//        public ActionResult Edit(int? dr_Id, int? p_Id)
//        {
//            if ((dr_Id == null) || (p_Id == null))
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            EditPatientFile_Table edit = db.EditPatientFile_Table.Find(dr_Id, p_Id);
//            if (edit == null)
//            {
//                return HttpNotFound();
//            }
//            PopulateDoctorsDropDownList(edit.dr_Id);
//            PopulatePatientDropDownList(edit.p_Id);

//            return View(edit);
//        }

        
//       //  POST: /EditPatient/Edit/5
//        [HttpPost, ActionName("Edit")]
//        [ValidateAntiForgeryToken]
//        public ActionResult EditPost(EditPatientFile_Table edit)
//        {
//            if (ModelState.IsValid)
//            {
//                // if primary key is exist
//               // if (Check(pm.prescription_Id, pm.medication_Id))
//               // {
//               //     ModelState.AddModelError("", "The patient is alredy have this medication");
//             //   }
//                db.Entry(edit).State = EntityState.Modified;
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            PopulateDoctorsDropDownList();
//            PopulatePatientDropDownList();

//            return View(edit);
//        }

        
//       //  GET: /EditPatient/Delete/5
//        public ActionResult Delete(int? dr_Id, int? p_Id)
//        {
//            if ((dr_Id == null) || (p_Id == null))
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            EditPatientFile_Table edit = db.EditPatientFile_Table.Find(dr_Id, p_Id);
//            if (edit == null)
//            {
//                return HttpNotFound();
//            }

//            return View(edit);
//        }

        
//     //    POST: /EditPatient/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public ActionResult DeletePost(int? dr_Id, int? pn_Id)
//        {
//            EditPatientFile_Table edit = db.EditPatientFile_Table.Find(dr_Id, pn_Id);
//            db.EditPatientFile_Table.Remove(edit);
//            db.SaveChanges();
//            return RedirectToAction("Index");
//        }
//        private void PopulatePatientDropDownList(object selectedpatient = null)
//        {
//            var patientQuery = from d in db.Patient_Table
//                               orderby d.p_Id
//                               select d;
//            ViewBag.p_Id = new SelectList(patientQuery, "p_Id", "P_f_name", selectedpatient);
//        }

//        private void PopulateDoctorsDropDownList(object selecteddoctor = null)
//        {
//            var doctorQuery = from d in db.Doctors_Table
//                              orderby d.dr_Id
//                              select d;
//            ViewBag.dr_Id = new SelectList(doctorQuery, "dr_Id", "dr_f_name", selecteddoctor);
//        }
//        public bool Check(int key1, int key2)
//        {
//            return db.EditPatientFile_Table.Any(x => x.dr_Id == key1 && x.p_Id == key2);
//        }
//    }
//}

