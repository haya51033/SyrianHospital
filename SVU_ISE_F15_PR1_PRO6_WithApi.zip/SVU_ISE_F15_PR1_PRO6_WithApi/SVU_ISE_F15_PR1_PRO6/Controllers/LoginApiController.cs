﻿using System.Web.Http;
using SVU_ISE_F15_PR1_PRO6.Models;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using SVU_ISE_F15_PR1_PRO6.Repos;

namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    [RoutePrefix("api/login")]
    public class LoginApiController : ApiController
    {
        private readonly IUserLogin _userLogin;

        public LoginApiController()
        {
            _userLogin = new UserLogin();
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Post([FromBody] PatientLoginRequestModel model)
        {
            if (string.IsNullOrEmpty(model.Username) || string.IsNullOrEmpty(model.Password)) return BadRequest();
            var patientId = _userLogin.LogIn(model.Username, model.Password);
            //string error = "Username or Password is not correct";
          

            if (patientId == 0) return Ok(ConvertTableEntryToViewModel(patientId));

            using (var context = new HospitalDatabaseEntities1())
            {
                var patient = context.Patient_Table.Find(patientId);
                return Ok(ConvertTableEntryToViewModel1(patient));
            }
        }


         private static PatientLoginRequestModel ConvertTableEntryToViewModel(int patientId)
        {
            return new PatientLoginRequestModel
            {
              PatientId = patientId              
            };
         }
         private static PatientLoginRequestModel ConvertTableEntryToViewModel1(Patient_Table entry)
         {
             return new PatientLoginRequestModel
             {
                 PatientId = entry.p_Id,
                 FirstName = entry.P_f_name,
                 LastName = entry.p_l_name,
                 Username = entry.p_username,
                 Gender = entry.p_gender
             };
         }

    }
}
