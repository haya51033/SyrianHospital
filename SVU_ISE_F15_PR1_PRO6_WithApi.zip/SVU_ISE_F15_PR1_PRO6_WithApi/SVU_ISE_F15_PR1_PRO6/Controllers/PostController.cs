﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using SVU_ISE_F15_PR1_PRO6.Models;




namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class PostController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Post/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            ViewBag.CurrentSort = sortOrder;
            ViewBag.publish_Date = String.IsNullOrEmpty(sortOrder) ? "date" : "";
            ViewBag.publisher = sortOrder == "pub" ? "_pub" : "pub";

            if (searchString != null)
            {
                pagePos = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;
            int pageNumber = (pagePos ?? 1);

            if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {

                var post = from p in db.Post_Table
                           select p;
                if (!String.IsNullOrEmpty(searchString))
                {
                    post = post.Where(s => s.title.Contains(searchString)
                        || s.description.Contains(searchString));
                }

                switch (sortOrder)
                {
                    case "date":
                        post = post.OrderByDescending(s => s.publish_Date);
                        break;
                    case "pup":
                        post = post.OrderBy(s => s.publisher);
                        break;
                    case "_pub":
                        post = post.OrderByDescending(s => s.publisher);
                        break;
                    default:
                        post = post.OrderBy(s => s.publish_Date);
                        break;
                }
                return View(post.ToList().ToPagedList(pageNumber, 8));
            }
            else if (profileData.username.StartsWith("dr_"))
            {

                var _post = from p in db.Post_Table
                            where p.publisher == profileData.username
                            select p;
                if (!String.IsNullOrEmpty(searchString))
                {
                    _post = _post.Where(s => s.title.Contains(searchString)
                        || s.description.Contains(searchString));
                }

                switch (sortOrder)
                {
                    case "date":
                        _post = _post.OrderByDescending(s => s.publish_Date);
                        break;
                    case "_pub":
                        _post = _post.OrderBy(s => s.publisher);
                        break;
                    case "pub":
                        _post = _post.OrderByDescending(s => s.publisher);
                        break;
                    default:
                        _post = _post.OrderBy(s => s.publish_Date);
                        break;
                }
                return View(_post.ToList().ToPagedList(pageNumber, 8));
            }
            else
            {
                return RedirectToAction("accessBlock", "Home");
            }
        }

        public ActionResult postsView(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            ViewBag.CurrentSort = sortOrder;
            ViewBag.publish_Date = String.IsNullOrEmpty(sortOrder) ? "date" : "";

            if (searchString != null)
            {
                pagePos = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;
            var post = from p in db.Post_Table.OrderByDescending(t => t.publish_Date).ThenByDescending(c => c.publish_Time)
                       select p;
            if (!String.IsNullOrEmpty(searchString))
            {
                post = post.Where(s => s.title.Contains(searchString)
                    || s.description.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "date":
                    post = post.OrderByDescending(s => s.publish_Date);
                    break;
                default:
                    post = post.OrderBy(s => s.publish_Date);
                    break;
            }
            int pageNumber = (pagePos ?? 1);
            return View(post.ToList().ToPagedList(pageNumber, 8));
        }

        //
        // GET: /Post/Details/5
        public ActionResult Details(int id)
        {
            return View(db.Post_Table.Find(id));
        }


        //
        // GET: /Post/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                return View();
            }
        }

        //
        // POST: /Post/Create
        [HttpPost]
        public ActionResult Create(Post_Table post, HttpPostedFileBase file)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            try
            {
                if (ModelState.IsValid)
                {
                    var today = DateTime.Today;
                    var currentTime = DateTime.Now.TimeOfDay;

                    post.publisher = profileData.username;
                    post.publish_Date = today;
                    post.publish_Time = currentTime;
                    if (file != null)
                    {
                        file.SaveAs(HttpContext.Server.MapPath("~/Images/")
                                                              + file.FileName);
                        post.ImagePath = file.FileName;
                    }

                    db.Post_Table.Add(post);
                    db.SaveChanges();
                    TempData["notice"] = "Post Title: " + post.title + "And Id: " + post.post_Id + "Added Successfully..";
                    return RedirectToAction("Index");

                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            return View();
        }

        //
        // GET: /Post/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Post_Table post = db.Post_Table.Find(id);
                if (post == null)
                {
                    return HttpNotFound();
                }
                return View(post);
            }
        }

        //
        // POST: /Post/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int? id, Post_Table postToUpdate)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            postToUpdate = db.Post_Table.Find(id);
            if (TryUpdateModel(postToUpdate, "",
                new string[] {"post_Id","publisher","title","description","article",
                    "publish_Date","publish_Time","edit_Date","edit_Time" }))
            {
                try
                {
                    db.SaveChanges();
                    TempData["notice"] = "Post Title: " + postToUpdate.title + "And Id: " + postToUpdate.post_Id + "Edited Successfully..";
                    return RedirectToAction("Index");
                }

                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");

                }
            }
            return View(postToUpdate);
        }

        //
        // GET: /Post/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Post_Table post = db.Post_Table.Find(id);
                if (post == null)
                {
                    return HttpNotFound();
                }
                return View(post);
            }
        }

        //
        // POST: /Post/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int? id, Post_Table post)
        {
            post = db.Post_Table.Find(id);
            db.Post_Table.Remove(post);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        public ActionResult LastPosts()
        {
            var last = db.Post_Table.OrderByDescending(u => u.publish_Date).ThenBy(u => u.publish_Time).Take(4);
            return View(last.ToList());
        }

        private static PostsViewModel ConvertTableEntryToViewModel(Post_Table entry)
        {
            return new PostsViewModel
            {
                Title = entry.title,
                Description = entry.description,
                Image = entry.ImagePath
            };
        }
    }
}
