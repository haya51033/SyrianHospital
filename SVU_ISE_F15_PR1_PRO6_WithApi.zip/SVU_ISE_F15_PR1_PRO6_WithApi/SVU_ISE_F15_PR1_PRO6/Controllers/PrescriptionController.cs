﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using AttributeRouting.Web.Http;


namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class PrescriptionController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Prescription/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || (profileData.username.StartsWith("dr_")) || profileData.username.StartsWith("Employee_"))
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.prescription_date = String.IsNullOrEmpty(sortOrder) ? "date" : "";
                ViewBag.p_Id = sortOrder == "p" ? "p_u" : "p";
                ViewBag.dr_Id = sortOrder == "dr" ? "dr_u" : "dr";

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var prescription = from s in db.Prescription_Table
                                   select s;

                if (!String.IsNullOrEmpty(searchString))
                {
                    prescription = prescription.Where(s => s.Patient_Table.p_username.Contains(searchString));
                }

                switch (sortOrder)
                {
                    case "date":
                        prescription = prescription.OrderByDescending(s => s.prescription_date);
                        break;
                    case "p":
                        prescription = prescription.OrderByDescending(s => s.Patient_Table.p_username);
                        break;
                    case "p_u":
                        prescription = prescription.OrderBy(s => s.Doctors_Table.dr_username);
                        break;
                    case "dr":
                        prescription = prescription.OrderByDescending(s => s.Doctors_Table.dr_username);
                        break;
                    case "dr_u":
                        prescription = prescription.OrderBy(s => s.Patient_Table.p_username);
                        break;
                    default:
                        prescription = prescription.OrderBy(s => s.prescription_date);
                        break;
                }

                int pageNumber = (pagePos ?? 1);
                if (profileData.username.StartsWith("dr_"))
                {
                    var dr_patients = from d in db.Prescription_Table
                                       join e in db.EditPatientFile_Table on d.p_Id equals e.p_Id
                                       where e.dr_Id == profileData.dr_Id && d.dr_Id == profileData.dr_Id
                                       orderby d.p_Id
                                       select d;
                    if (!String.IsNullOrEmpty(searchString))
                    {
                        dr_patients = dr_patients.Where(s => s.Patient_Table.p_username.Contains(searchString));
                    }

                    switch (sortOrder)
                    {
                        case "date":
                            dr_patients = dr_patients.OrderByDescending(s => s.prescription_date);
                            break;
                        case "p":
                            dr_patients = dr_patients.OrderByDescending(s => s.Patient_Table.p_username);
                            break;
                        case "p_u":
                            dr_patients = dr_patients.OrderBy(s => s.Doctors_Table.dr_username);
                            break;
                        case "dr":
                            dr_patients = dr_patients.OrderByDescending(s => s.Doctors_Table.dr_username);
                            break;
                        case "dr_u":
                            dr_patients = dr_patients.OrderBy(s => s.Patient_Table.p_username);
                            break;
                        default:
                            dr_patients = dr_patients.OrderBy(s => s.prescription_date);
                            break;
                    }
                    return View(dr_patients.ToList().ToPagedList(pageNumber, 10));
                }
                else
                {
                    return View(prescription.ToList().ToPagedList(pageNumber, 10));
                }
            }    
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // GET: /Prescription/Details/5
        public ActionResult Details(int id)
        {
             var profileData = this.Session["UserProfile"] as Users_Table;

             if (profileData == null)
             {
                 return RedirectToAction("accessBlock", "Home");
             }
             else
             {
                 return View(db.Prescription_Table.Find(id));
             }
        }

        //
        // GET: /Prescription/Create
        public ActionResult Create()
        {
             var today = DateTime.Today;
           var profileData = this.Session["UserProfile"] as Users_Table;

           if (profileData == null)
           {
               return RedirectToAction("accessBlock", "Home");
           }
           else
           {
               if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
               {
                   PopulatePatientDropDownList();
                   PopulateDoctorsDropDownList();
                   Prescription_Table prescription = new Prescription_Table();
                   prescription.prescription_date = today;
                   return View(prescription);
               }

               if (profileData.username.StartsWith("dr_"))
               {

                   PopulatePatientDropDownList();
                   Prescription_Table prescription = new Prescription_Table();
                   prescription.dr_Id = profileData.dr_Id;
                   prescription.prescription_date = today;
                   return View(prescription);
               }
               return View();
           }   
        }

        //
        // POST: /Prescription/Create
        [HttpPost]
        public ActionResult Create(Prescription_Table prescription)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            try
            {
                if (ModelState.IsValid)
                {
                    db.Prescription_Table.Add(prescription);
                    db.SaveChanges();
                    TempData["notice"] = "Prescription Id: " + prescription.prescription_Id + ", Successfully registered";
                    TempData["Prescription_Id"] = prescription.prescription_Id;
                    return RedirectToAction("Index");
                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
           
                PopulatePatientDropDownList(prescription.p_Id);
            
            PopulateDoctorsDropDownList(prescription.dr_Id);

            return View(prescription);
        }

        //
        // GET: /Prescription/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }

            else 
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                Prescription_Table prescription = db.Prescription_Table.Find(id);
                if (prescription == null)
                {
                    return HttpNotFound();
                }

                PopulatePatientDropDownList(prescription.p_Id);
                PopulateDoctorsDropDownList(prescription.dr_Id);
                return View(prescription);
            }
        }

        //
        // POST: /Prescription/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var prescriptionToUpdate = db.Prescription_Table.Find(id);
            if (TryUpdateModel(prescriptionToUpdate, "",
                new string[] { "prescription_Id", "prescription_date", "p_Id", "dr_Id" }))
            {
                try
                {
                    db.SaveChanges();
                    TempData["notice"] = "Prescription Id: " + prescriptionToUpdate.prescription_Id + ", Successfully Edited";
                    return RedirectToAction("Index");
                }
                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
            }
            PopulatePatientDropDownList();
            PopulateDoctorsDropDownList();
            return View(prescriptionToUpdate);
        }

        //
        // GET: /Prescription/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else 
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Prescription_Table prescription = db.Prescription_Table.Find(id);
                if (prescription == null)
                {
                    return HttpNotFound();
                }
                return View(prescription);
            }
        }

        //
        // POST: /Prescription/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeletePost(int? id)
        {
            Prescription_Table prescription = db.Prescription_Table.Find(id);
            db.Prescription_Table.Remove(prescription);
            db.SaveChanges();
            return RedirectToAction("Index");

        }
        private void PopulatePatientDropDownList(object selectedpatient = null)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData.username.StartsWith("dr_"))
            {
                var patientQuery = from d in db.Patient_Table
                                   join e in db.EditPatientFile_Table on d.p_Id equals e.p_Id
                                   where e.dr_Id == profileData.dr_Id
                                   orderby d.p_Id
                                   select d;
                ViewBag.p_Id = new SelectList(patientQuery, "p_Id", "p_username", selectedpatient);
            }
            else
            {
                var patientQuery = from d in db.Patient_Table
                                   orderby d.p_Id
                                   select d;
                ViewBag.p_Id = new SelectList(patientQuery, "p_Id", "p_username", selectedpatient);
            }
           
        }

        private void PopulateDoctorsDropDownList(object selecteddoctor = null)
        {
            var doctorQuery = from d in db.Doctors_Table
                              orderby d.dr_Id
                              select d;
            ViewBag.dr_Id = new SelectList(doctorQuery, "dr_Id", "dr_username", selecteddoctor);
        }

        public ActionResult doctorList()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            var doctor_prescription_list = from p in db.Prescription_Table
                                           join d in db.Doctors_Table on p.dr_Id equals d.dr_Id
                                           where p.dr_Id == profileData.dr_Id
                                           select p;
            return View(doctor_prescription_list);
        }
    }
}
