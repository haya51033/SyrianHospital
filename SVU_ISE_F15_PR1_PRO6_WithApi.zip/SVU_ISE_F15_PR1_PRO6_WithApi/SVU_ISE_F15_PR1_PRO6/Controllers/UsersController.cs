﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using SVU_ISE_F15_PR1_PRO6;

namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class UsersController : ApiController
    {
        private HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();

        // GET api/Users
        public IQueryable<Users_Table> GetUsers_Table()
        {
            return db.Users_Table;
        }

        // GET api/Users/5
        [ResponseType(typeof(Users_Table))]
        public IHttpActionResult GetUsers_Table(int id)
        {
            Users_Table users_table = db.Users_Table.Find(id);
            if (users_table == null)
            {
                return NotFound();
            }

            return Ok(users_table);
        }

        // PUT api/Users/5
        public IHttpActionResult PutUsers_Table(int id, Users_Table users_table)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != users_table.Id)
            {
                return BadRequest();
            }

            db.Entry(users_table).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Users_TableExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/Users
        [ResponseType(typeof(Users_Table))]
        public IHttpActionResult PostUsers_Table(Users_Table users_table)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Users_Table.Add(users_table);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (Users_TableExists(users_table.Id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = users_table.Id }, users_table);
        }

        // DELETE api/Users/5
        [ResponseType(typeof(Users_Table))]
        public IHttpActionResult DeleteUsers_Table(int id)
        {
            Users_Table users_table = db.Users_Table.Find(id);
            if (users_table == null)
            {
                return NotFound();
            }

            db.Users_Table.Remove(users_table);
            db.SaveChanges();

            return Ok(users_table);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Users_TableExists(int id)
        {
            return db.Users_Table.Count(e => e.Id == id) > 0;
        }
    }
}