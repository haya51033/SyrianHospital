﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using SVU_ISE_F15_PR1_PRO6.Models;



namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class DiagnosisController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Diagnosis/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_") || profileData.username.StartsWith("Employee_"))
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.disease_name = String.IsNullOrEmpty(sortOrder) ? "dis" : "";
                ViewBag.diagnosis_date = sortOrder == "Date" ? "dia_date" : "Date";
                ViewBag.p_username = sortOrder == "p_username" ? "p_" : "p_username";
                ViewBag.dr_Id = sortOrder == "dr_Id" ? "dr_" : "dr_Id";

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var diagnosis = from s in db.Diagnosis_Table
                                select s;
                if (!String.IsNullOrEmpty(searchString))
                {
                    diagnosis = diagnosis.Where(d => d.p_username.Contains(searchString));
                }


                switch (sortOrder)
                {
                    case "dis":
                        diagnosis = diagnosis.OrderByDescending(s => s.disease_name);
                        break;
                    case "Date":
                        diagnosis = diagnosis.OrderBy(s => s.diagnosis_date);
                        break;
                    case "dia_date":
                        diagnosis = diagnosis.OrderByDescending(s => s.diagnosis_date);
                        break;
                    case "p_username":
                        diagnosis = diagnosis.OrderBy(s => s.p_username);
                        break;
                    case "p_":
                        diagnosis = diagnosis.OrderByDescending(s => s.p_username);
                        break;
                    case "dr_Id":
                        diagnosis = diagnosis.OrderBy(s => s.dr_Id);
                        break;
                    case "dr_":
                        diagnosis = diagnosis.OrderByDescending(s => s.dr_Id);
                        break;
                    default:
                        diagnosis = diagnosis.OrderBy(s => s.disease_name);
                        break;
                }

                int pageNumber = (pagePos ?? 1);
                if (profileData.username.StartsWith("dr_"))
                {
                  var doctor_diagnosis_list = from p in db.Diagnosis_Table
                                            join dr in db.Doctors_Table on p.dr_Id equals dr.dr_Id
                                            where dr.dr_Id == profileData.dr_Id
                                            select p;

                    if (!String.IsNullOrEmpty(searchString))
                    {
                        doctor_diagnosis_list = doctor_diagnosis_list.Where(d => d.p_username.Contains(searchString));
                    }


                    switch (sortOrder)
                    {
                        case "dis":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderByDescending(s => s.disease_name);
                            break;
                        case "Date":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderBy(s => s.diagnosis_date);
                            break;
                        case "dia_date":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderByDescending(s => s.diagnosis_date);
                            break;
                        case "p_username":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderBy(s => s.p_username);
                            break;
                        case "p_":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderByDescending(s => s.p_username);
                            break;
                        case "dr_Id":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderBy(s => s.dr_Id);
                            break;
                        case "dr_":
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderByDescending(s => s.dr_Id);
                            break;
                        default:
                            doctor_diagnosis_list = doctor_diagnosis_list.OrderBy(s => s.disease_name);
                            break;
                    }

                    return View(doctor_diagnosis_list.ToList().ToPagedList(pageNumber, 10));
                }
                else
                {
                    return View(diagnosis.ToList().ToPagedList(pageNumber, 10));
                }
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // GET: /Diagnosis/Details/5
        public ActionResult Details(int id)
        {
             var profileData = this.Session["UserProfile"] as Users_Table;

             if (profileData == null)
             {
                 return RedirectToAction("accessBlock", "Home");
             }
             else
             {
                 return View(db.Diagnosis_Table.Find(id));
             }
        }

        //
        // GET: /Diagnosis/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                if (profileData.username.StartsWith("Admin_"))
                {
                    PopulatePatientDropDownList();
                    PopulateDoctorsDropDownList();

                    return View();
                }
                if (profileData.username.StartsWith("dr_"))
                {
                    PopulatePatientDropDownList();
                    Diagnosis_Table d = new Diagnosis_Table();
                    d.dr_Id = profileData.dr_Id;
                    return View(d);
                }
                return View();
            }
        }


        //
        // POST: /Diagnosis/Create
        [HttpPost]
        public ActionResult Create(Diagnosis_Table diagnosis)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Diagnosis_Table.Add(diagnosis);
                    db.SaveChanges();
                    TempData["notice"] = "Diagnosis name: '" + diagnosis.disease_name + "' was successfully added for Patient username: '"+diagnosis.p_username+"'.";
                    
                    return RedirectToAction("Index");
                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            PopulatePatientDropDownList(diagnosis.p_username);
            PopulateDoctorsDropDownList(diagnosis.dr_Id);

            return View(diagnosis);
        }

        //
        // GET: /Diagnosis/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }

            else if(profileData.username.StartsWith("Admin_")|| profileData.username.StartsWith("dr_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Diagnosis_Table diagnosis = db.Diagnosis_Table.Find(id);
                if (diagnosis == null)
                {
                    return HttpNotFound();
                }
                PopulatePatientDropDownList(diagnosis.p_username);
                PopulateDoctorsDropDownList(diagnosis.dr_Id);

                return View(diagnosis);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
           
        }

        //
        // POST: /Diagnosis/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var diagnosisToUpdate = db.Diagnosis_Table.Find(id);
            if (TryUpdateModel(diagnosisToUpdate, "",
                new string[] { "diagnosis_Id", "diagnosis_date", "disease_name", "p_username", "dr_Id",
                               "symptoms","disease_description"}))
            {
                try
                {
                    db.SaveChanges();
                    TempData["notice"] = "Diagnosis name: '" + diagnosisToUpdate.disease_name + "' was successfully Edited for Patient id: '" + diagnosisToUpdate.p_username + "'.";

                    return RedirectToAction("Index");
                }
                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
            }
            PopulatePatientDropDownList();
            PopulateDoctorsDropDownList();
            return View(diagnosisToUpdate);
        }

        //
        // GET: /Diagnosis/Delete/5
        public ActionResult Delete(int? id)
        {
             var profileData = this.Session["UserProfile"] as Users_Table;

             if (profileData == null)
             {
                 return RedirectToAction("accessBlock", "Home");
             }
             else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
             {
                 if (id == null)
                 {
                     return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                 }
                 Diagnosis_Table diagnosis = db.Diagnosis_Table.Find(id);
                 if (diagnosis == null)
                 {
                     return HttpNotFound();
                 }
                 return View(diagnosis);
             }
             else
             {
                 return RedirectToAction("accessBlock1", "Home");
             }
        }

        //
        // POST: /Diagnosis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeletePost(int? id)
        {
            Diagnosis_Table diagnosis = db.Diagnosis_Table.Find(id);
            db.Diagnosis_Table.Remove(diagnosis);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        private void PopulatePatientDropDownList(object selectedpatient = null)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData.username.StartsWith("dr_"))
            {
                var patientQuery = from d in db.Patient_Table
                                   join e in db.EditPatientFile_Table on d.p_Id equals e.p_Id
                                   where e.dr_Id == profileData.dr_Id
                                   orderby d.p_username
                                   select d;
                ViewBag.p_Id = new SelectList(patientQuery, "p_username", "p_username", selectedpatient);
            }
            else
            {
                var patientQuery = from d in db.Patient_Table
                                   orderby d.p_username
                                   select d;
                ViewBag.p_Id = new SelectList(patientQuery, "p_username", "p_username", selectedpatient);
            }
          
        }

        private void PopulateDoctorsDropDownList(object selecteddoctor = null)
        {
            var doctorQuery = from d in db.Doctors_Table
                               orderby d.dr_Id
                               select d;
            ViewBag.dr_Id = new SelectList(doctorQuery, "dr_Id", "dr_username", selecteddoctor);
        }

        public ActionResult doctorList()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            var doctor_diagnosis_list = from p in db.Diagnosis_Table
                                        join dr in db.Doctors_Table on p.dr_Id equals dr.dr_Id
                                        where dr.dr_Id == profileData.dr_Id
                                        select p;
            return View(doctor_diagnosis_list);
        }

      
    }
}
