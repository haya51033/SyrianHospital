﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SVU_ISE_F15_PR1_PRO6.Models;

namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
   [RoutePrefix("api/LastUpdate")]
    public class LastUpdateAPIController : ApiController
    {
        [HttpGet]
       [Route("{patientId}")] //http://localhost:2917/api/LastUpdate/2
        public IHttpActionResult Get(int patientId)
        {
            if (patientId == 0) return BadRequest("Please provide parameters");
            using (var context = new HospitalDatabaseEntities1())
            {      
                var lastUpdate = context.Prescription_Table.Where(m => m.p_Id == patientId).OrderByDescending(t=>t.prescription_date).FirstOrDefault();
                return Ok(ConvertTableEntryToViewModel(lastUpdate));
            }
        }

          private static LastUpdateOnPrescriptionModels ConvertTableEntryToViewModel(Prescription_Table entry)
            {

                return new LastUpdateOnPrescriptionModels 
                {
                   //prescriptionId = entry.prescription_Id,
                   prescriptionDate = string.Format("{0:d}", entry.prescription_date),
                   patientId = entry.p_Id
                };
            }
    }

       

}
