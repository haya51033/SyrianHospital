﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using SVU_ISE_F15_PR1_PRO6.Models;



namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class PatientController : Controller
    {

        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Patient/
        public ActionResult Index(int? pagePos, string sortOrder,string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_") || profileData.username.StartsWith("Employee_"))
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.p_l_name = String.IsNullOrEmpty(sortOrder) ? "l_name" : "";
                ViewBag.p_birthday = sortOrder == "Date" ? "birthday" : "Date";

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var patient = from s in db.Patient_Table
                              select s;
                if (!String.IsNullOrEmpty(searchString))
                {
                    patient = patient.Where(s => s.p_phone1.Contains(searchString)
                        || s.p_phone2.Contains(searchString));
                }
         

                switch (sortOrder)
                {
                    case "l_name":
                        patient = patient.OrderByDescending(s => s.p_l_name);
                        break;
                    case "Date":
                        patient = patient.OrderBy(s => s.p_birthday);
                        break;
                    case "birthday":
                        patient = patient.OrderByDescending(s => s.p_birthday);
                        break;
                    default:
                        patient = patient.OrderBy(s => s.p_l_name);
                        break;
                }

                int pageNumber = (pagePos ?? 1);
                if (profileData.username.StartsWith("dr_"))
                {
                    var doctor_patients_list = from p in db.Patient_Table
                                               join e in db.EditPatientFile_Table on p.p_Id equals e.p_Id
                                               join d in db.Doctors_Table on e.dr_Id equals d.dr_Id
                                               where e.dr_Id == profileData.dr_Id
                                               select p;
               
                if (!String.IsNullOrEmpty(searchString))
                {
                    doctor_patients_list = doctor_patients_list.Where(s => s.p_phone1.Contains(searchString)
                        || s.p_phone2.Contains(searchString));
                }
                switch (sortOrder)
                {
                    case "l_name":
                        doctor_patients_list = doctor_patients_list.OrderByDescending(s => s.p_l_name);
                        break;
                    case "Date":
                        doctor_patients_list = doctor_patients_list.OrderBy(s => s.p_birthday);
                        break;
                    case "birthday":
                        doctor_patients_list = doctor_patients_list.OrderByDescending(s => s.p_birthday);
                        break;
                    default:
                        doctor_patients_list = doctor_patients_list.OrderBy(s => s.p_l_name);
                        break;
                }   
                     return View(doctor_patients_list.ToList().ToPagedList(pageNumber,10));
                }
                else
                {
                    return View(patient.ToList().ToPagedList(pageNumber, 10));
                }
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // GET: /Patient/Details/5
        public ActionResult Details(int id)
        {
             var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
             else
            {
                return View(db.Patient_Table.Find(id));
            }
        }

        //
        // GET: /Patient/Create
        public ActionResult Create()
        {
              var profileData = this.Session["UserProfile"] as Users_Table;

              if (profileData == null)
              {
                  return RedirectToAction("accessBlock", "Home");
              }
              else
              {
                  return View();
              }
        }

        //
        // POST: /Patient/Create
        [HttpPost]
        public ActionResult Create(Patient_Table patient)
        {
         var profileData = this.Session["UserProfile"] as Users_Table;

            try
            {
                if (ModelState.IsValid)
                {
                    var currentTime = DateTime.Now.TimeOfDay;

                    //calculte age:
                    var today = DateTime.Today;
                    patient.p_age = today.Year - patient.p_birthday.Value.Year;

                    patient.created_By = profileData.username;
                    patient.date_of_create = today;
                    patient.time_of_create = currentTime;

                     var Users_Table = new Users_Table()
                    {
                        username = patient.p_username ,
                        password = patient.p_password,
                        user_type = "Patient",
                        p_Id= patient.p_Id
                    };
                    
                     bool patientExist = db.Patient_Table.Any(p => ((p.p_phone1 == patient.p_phone1)
                                                            || (p.p_phone1 == patient.p_phone2)
                                                            || (p.p_phone2 == patient.p_phone1)
                                                            || (p.p_phone2 == patient.p_phone2))
                                                            && (p.P_f_name == patient.P_f_name)
                                                            && (p.p_l_name == patient.p_l_name)
                                                            && (p.p_m_name == patient.p_m_name));
                   
                           
                         if (!patientExist)
                         {
                             var editPatient_Table = new EditPatientFile_Table()
                             {
                                 dr_Id = Convert.ToInt32(profileData.dr_Id),
                                 p_Id = patient.p_Id,
                                 start_Following = today
                             };

                             db.Patient_Table.Add(patient);
                             db.Users_Table.Add(Users_Table);
                             if (profileData.username.StartsWith("dr_"))
                             {
                             db.EditPatientFile_Table.Add(editPatient_Table);
                             }
                             db.SaveChanges();
                             TempData["notice"] = "Successfully registered for Patient:\n Id: " + patient.p_Id + " Name: " + patient.P_f_name + " " + patient.p_l_name;
                             TempData["prescription"] = patient.p_Id;
                             TempData["diagnosis"] = patient.p_Id;
                         }
                         else // user is alrady exist
                         {
                             var editPatient_Table = new EditPatientFile_Table()
                             {
                                 dr_Id = Convert.ToInt32(profileData.dr_Id),
                                 p_Id = patient.p_Id,
                                 start_Following = today
                             };

                             // get p_username whish is existed
                             patient.p_username = db.Patient_Table.First(p => ((p.p_phone1 == patient.p_phone1)
                                                                || (p.p_phone1 == patient.p_phone2)
                                                                || (p.p_phone2 == patient.p_phone1)
                                                                || (p.p_phone2 == patient.p_phone2))
                                                                && (p.P_f_name == patient.P_f_name)
                                                                && (p.p_l_name == patient.p_l_name)
                                                                && (p.p_m_name == patient.p_m_name)).p_username;

                             // get p_Id whish is existed
                             patient.p_Id = db.Patient_Table.First(p => ((p.p_phone1 == patient.p_phone1)
                                                                || (p.p_phone1 == patient.p_phone2)
                                                                || (p.p_phone2 == patient.p_phone1)
                                                                || (p.p_phone2 == patient.p_phone2))
                                                                && (p.P_f_name == patient.P_f_name)
                                                                && (p.p_l_name == patient.p_l_name)
                                                                && (p.p_m_name == patient.p_m_name)).p_Id;
                             // get p_Id whish is existed
                             editPatient_Table.p_Id = db.Patient_Table.First(p => ((p.p_phone1 == patient.p_phone1)
                                                               || (p.p_phone1 == patient.p_phone2)
                                                               || (p.p_phone2 == patient.p_phone1)
                                                               || (p.p_phone2 == patient.p_phone2))
                                                               && (p.P_f_name == patient.P_f_name)
                                                               && (p.p_l_name == patient.p_l_name)
                                                               && (p.p_m_name == patient.p_m_name)).p_Id;

                             if (profileData.username.StartsWith("dr_"))
                             {
                                 bool edit_Isexist = db.EditPatientFile_Table.Any(p => p.p_Id == editPatient_Table.p_Id 
                                                                               && p.dr_Id == editPatient_Table.dr_Id);
                                 if (edit_Isexist)
                                 {
                                     TempData["Error"]= "The Patient is already registerd in hospital and in your patients list";
                                     TempData["prescription"] = patient.p_Id;
                                     TempData["diagnosis"] = patient.p_Id;
                                 }
                                 else
                                 {
                                     db.EditPatientFile_Table.Add(editPatient_Table);
                                     db.SaveChanges();
                                     TempData["Error"] = "new Patient inserting was ejected, Because The Patient is already registered in the hospital with username: "+patient.p_username+" and Id: "+patient.p_Id+", but we have added  successfully to your List";
                                     TempData["prescription"] = patient.p_Id;
                                     TempData["diagnosis"] = patient.p_username;
                                 }
                             }
                             else
                             {
                                 TempData["Error"] = "The Patient Is already registered In Hospital..\nwith Username: " + patient.p_username+", and Id: "+patient.p_Id;
                             }
                         }
                     }
                   return RedirectToAction("Index");
                }
            
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            PopulatePatientDropDownList(patient.p_Id);
            return View(patient);
        }

        

        //
        // GET: /Patient/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }

            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Patient_Table patient = db.Patient_Table.Find(id);
                EditPatientFile_Table Edit = db.EditPatientFile_Table.Find(id, id);
                if (patient == null)
                {
                    return HttpNotFound();
                }
                PopulatePatientDropDownList(patient.p_Id);
                return View(patient);
            }
            else // if dr try to update patient
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // POST: /Patient/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var patientToUpdate = db.Patient_Table.Find(id);
            if (TryUpdateModel(patientToUpdate, "",
                new string[] { "p_Id", "P_f_name", "p_m_name","p_l_name", "p_username", "p_password",
                               "p_gender","p_birthday","p_age","p_marital_status","p_child_number",
                               "p_phone1","p_phone2","p_address","old_illnesses","allergy_for","edited_By",
                               "editFile_date","editFile_time"}))
            {
                try
                {
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
            }     
            PopulatePatientDropDownList();
            return View(patientToUpdate);  
            }

      

        //
        // GET: /Patient/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Patient_Table patient = db.Patient_Table.Find(id);
                if (patient == null)
                {
                    return HttpNotFound();
                }
                return View(patient);
            }
        }
        //
        // POST: /Patient/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeletePost(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                Patient_Table patient = db.Patient_Table.Find(id);
                db.Patient_Table.Remove(patient);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                EditPatientFile_Table e = db.EditPatientFile_Table.Find(profileData.dr_Id,id);
                db.EditPatientFile_Table.Remove(e);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
                    
        }

        private void PopulatePatientDropDownList(object selectedpatient = null)
        {
            var patientQuery = from p in db.Patient_Table
                               orderby p.P_f_name
                               select p;
            ViewBag.p_Id = new SelectList(patientQuery, "p_Id", "p_username", selectedpatient);
        }

        public ActionResult doctorList()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            int? pagePos = 1;
            int pageNumber = (pagePos ?? 1);
            var doctor_patients_list = from p in db.Patient_Table
                                       join e in db.EditPatientFile_Table on p.p_Id equals e.p_Id
                                       join d in db.Doctors_Table on e.dr_Id equals d.dr_Id
                                       where e.dr_Id == profileData.dr_Id
                                       select p;
            return View(doctor_patients_list.ToList().ToPagedList(pageNumber,10));

        }
    }

}
