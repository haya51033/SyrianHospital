﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;


namespace SVU_ISE_F15_PR1_PRO6.Controllers
{

    public class AccountController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Login/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Users_Table user)
        {
            //bool notPatient = db.Users_Table.Any(z => z.username == user.username.StartsWith("dr_").ToString() || z.username == user.username.StartsWith("Admin_").ToString());
            //if (!notPatient)
            //{
            //    return RedirectToAction("accessBlock1", "Home");
            //}
            if (ModelState.IsValid)
            {
                bool userExist = db.Users_Table.Any(o => o.username == user.username && o.password == user.password);
                if (userExist)
                {
                    
                    // get dr_id and save in session to use it showing his patients:
                    user.dr_Id = db.Users_Table.First(a => a.username == user.username).dr_Id;
                    if (user.username.StartsWith("dr_") || user.username.StartsWith("Admin_") || user.username.StartsWith("Employee_"))
                    {
                        // assign user variable in session:
                        var userData = new Users_Table()
                        {
                            Id = user.Id,
                            username = user.username,
                            user_type = user.user_type,
                            dr_Id = user.dr_Id,
                            p_Id = user.p_Id

                        };
                        // set session:
                        System.Web.HttpContext.Current.Session["UserProfile"] = userData;

                        /*
                          Remember: to output session variables:
                         *       
                         * var profileData = this.Session["UserProfile"] as Users_Table;
                         */

                        return RedirectToAction("UsercontrolPanel", "Home");
                    }
                    else
                    {
                        return RedirectToAction("accessBlock1", "Home");
                    }

                }
                else
                {
                    TempData["error"] = "Login data is incorrect! \n Please re enter correct username and password..";
                    return RedirectToAction("Login", "Account");
                }

            }
            return View(user);
        }

        
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();

            return View("Logout");
        }

    }
}

