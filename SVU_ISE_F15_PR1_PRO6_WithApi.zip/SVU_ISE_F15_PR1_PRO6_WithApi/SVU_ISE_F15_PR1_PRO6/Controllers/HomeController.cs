﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using SVU_ISE_F15_PR1_PRO6.Models;

namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class HomeController : Controller
    {

        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult UserControlPanel()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                var username = profileData.username;
                ViewBag.Message = username + " أهلا وسهلاً  ";
                return View();
            }
        }

        public ActionResult PatientFile(int id)
        {
            var file = from p in db.Patient_Table
                       where p.p_Id == id
                       select p.P_f_name;

            ViewBag.file = file;
            return View(file);
        }
        public ActionResult About()
        {
            ViewBag.Message = "SVU ISE F15 PR1 Project 6";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult accessBlock() 
        {
            return View();
        }

        public ActionResult accessBlock1()
        {
            return View();
        }

        public ActionResult LastPosts()
        {
            var last = db.Post_Table.OrderByDescending(u => u.publish_Date).ThenBy(u => u.publish_Time).Take(3);
            return View(last.ToList());
        }
    }
}