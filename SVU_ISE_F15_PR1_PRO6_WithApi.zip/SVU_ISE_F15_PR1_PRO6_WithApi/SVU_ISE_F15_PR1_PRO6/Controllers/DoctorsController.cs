﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using System.Web.Security;
using AttributeRouting.Web.Http;



namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class DoctorsController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Doctors/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_"))
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.dr_l_name = String.IsNullOrEmpty(sortOrder) ? "l_name" : "";
                ViewBag.dr_specialization = sortOrder == "sp1" ? "sp" : "sp1";
                ViewBag.dr_username = sortOrder == "us1" ? "us" : "us1";
                ViewBag.dr_birthday = sortOrder == "Date" ? "birthday" : "Date";
                int pageNumber = (pagePos ?? 1);

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var doctor = from s in db.Doctors_Table
                              select s;
                if (!String.IsNullOrEmpty(searchString))
                {
                    doctor = doctor.Where(s => s.dr_phone1.Contains(searchString)
                        || s.dr_phone2.Contains(searchString));
                }


                switch (sortOrder)
                {
                    case "l_name":
                        doctor = doctor.OrderByDescending(s => s.dr_l_name);
                        break;
                    case "Date":
                        doctor = doctor.OrderBy(s => s.dr_birthday);
                        break;
                    case "birthday":
                        doctor = doctor.OrderByDescending(s => s.dr_birthday);
                        break;
                    case "sp":
                        doctor = doctor.OrderBy(s => s.dr_specialization);
                        break;
                    case "sp1":
                        doctor = doctor.OrderByDescending(s=> s.dr_specialization);
                        break;
                    case "us":
                        doctor = doctor.OrderBy(s => s.dr_username);
                        break;
                    case "us1":
                        doctor = doctor.OrderByDescending(s => s.dr_username);
                        break;
                    default:
                        doctor = doctor.OrderBy(s => s.dr_l_name);
                        break;
                }
                return View(doctor.ToList().ToPagedList(pageNumber, 10));
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // GET: /Doctors/Details/5
        public ActionResult Details(int id)
        {
              var profileData = this.Session["UserProfile"] as Users_Table;

              if (profileData == null)
              {
                  return RedirectToAction("accessBlock", "Home");
              }
              else if(profileData.username.StartsWith("Admin_"))
              {
                  return View(db.Doctors_Table.Find(id));
              }
              else
              {
                  return RedirectToAction("accessBlock1", "Home");
              }
        }

        //
        // GET: /Doctors/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("dr_"))
            {
                return RedirectToAction("accessBlock1", "Home");
            }
            else
            {
                PopulateDoctorsDropDownList();
                return View();
            }
        }

        //
        // POST: /Doctors/Create
        [HttpPost]
        public ActionResult Create(Doctors_Table doctor)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            try
            {
                if (ModelState.IsValid)
                {
                    //calculte age:
                    var today = DateTime.Today;
                    doctor.dr_age = today.Year - doctor.dr_birthday.Value.Year;
                    // add spesial charcters 'dr' to doctor's username"
                    doctor.dr_username = "dr_" + doctor.dr_username; 

                    var Users_Table = new Users_Table()
                    {
                        username = doctor.dr_username ,
                        password = doctor.dr_password,
                        user_type = "Doctor",
                        dr_Id= doctor.dr_Id
                    };
                   
                    db.Doctors_Table.Add(doctor);
                    db.Users_Table.Add(Users_Table);
                   

                    db.SaveChanges();
                    TempData["notice"] = "Successfully registered for Doctor:\n Id: " + doctor.dr_Id + " Name: " + doctor.dr_f_name + " " + doctor.dr_l_name;
                    return RedirectToAction("Index");
                }
            }
                catch(RetryLimitExceededException)
            {
                    ModelState.AddModelError("","Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
                 PopulateDoctorsDropDownList(doctor.dr_Id);
                 return View(doctor);
            }

        //
        // GET: /Doctors/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }

            else if (profileData.username.StartsWith("Admin_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Doctors_Table doctor = db.Doctors_Table.Find(id);
                if (doctor == null)
                {
                    return HttpNotFound();
                }
                PopulateDoctorsDropDownList(doctor.dr_Id);
                return View(doctor);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // POST: /Doctors/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(Doctors_Table doctor)
        {
            if (ModelState.IsValid)
            {
               
                db.Entry(doctor).State = EntityState.Modified;
                db.SaveChanges();
                TempData["notice"] = " Edit for Doctor:\n Id: " + doctor.dr_Id + " Name: '" + doctor.dr_f_name + " " + doctor.dr_l_name + "' was done Successfully";

                return RedirectToAction("Index");
            }
            PopulateDoctorsDropDownList();
            return View(doctor);

            //if (id == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}

            //var doctorToUpdate = db.Doctors_Table.Find(id);

            //if (TryUpdateModel(doctorToUpdate, "",
            //    new string[] { "dr_Id", "dr_f_name", "dr_l_name", "dr_specialization", 
            //                   "dr_email", "dr_phone1","dr_phone2","dr_gender","dr_address",
            //                   "dr_birthday","dr_age","dr_username" }))
            //{
            //    try
            //    {
            //            db.SaveChanges();
            //            TempData["notice"] = " Edit for Doctor:\n Id: " + doctorToUpdate.dr_Id + " Name: '" + doctorToUpdate.dr_f_name + " " + doctorToUpdate.dr_l_name + "' was done Successfully";
            //            return RedirectToAction("Index");
            //    }
            //    catch (RetryLimitExceededException)
            //    {
            //        ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");

            //    }
            //}
            //PopulateDoctorsDropDownList();
            //return View(doctorToUpdate);  
        }   

        //
        // GET: /Doctors/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if(profileData.username.StartsWith("Admin_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Doctors_Table doctor = db.Doctors_Table.Find(id);
                if (doctor == null)
                {
                    return HttpNotFound();
                }
                return View(doctor);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }
        //
        // POST: /Doctors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeletePost(int? id)
        {
            Doctors_Table doctor = db.Doctors_Table.Find(id);
            db.Doctors_Table.Remove(doctor);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        private void PopulateDoctorsDropDownList(object selecteddoctor = null)
        {
            var doctorsQuery = from d in db.Doctors_Table
                           orderby d.dr_f_name
                           select d;
            ViewBag.dr_Id = new SelectList(doctorsQuery, "dr_Id", "dr_f_name", selecteddoctor);
        }

      
    }
}
