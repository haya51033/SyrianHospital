﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.ComponentModel.DataAnnotations;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;

namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class MedicationController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();

        //
        // GET: /Medication/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData != null)
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.medication_name = String.IsNullOrEmpty(sortOrder) ? "m_name" : "";

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var medication = from s in db.Medication_Table
                                 select s;

                if (!String.IsNullOrEmpty(searchString))
                {
                    medication = medication.Where(s => s.medication_name.Contains(searchString));     
                }
                 switch (sortOrder)
                {
                    case "m_name":
                        medication = medication.OrderBy(s => s.medication_name);
                        break;
                    default:
                        medication = medication.OrderByDescending(s => s.medication_name);
                        break;
                }

                 int pageNumber = (pagePos ?? 1);
                 if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_")) 
                 {
                     return View(medication.ToList().ToPagedList(pageNumber, 10));
                 }
                 else
                 {
                     return RedirectToAction("accessBlock1", "Home");

                 }
            }
            else
            {
                return RedirectToAction("accessBlock", "Home");
            }
        }

        //
        // GET: /Medication/Details/5
        public ActionResult Details(int id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                return View(db.Medication_Table.Find(id));
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }          
        }

        //
        // GET: /Medication/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                return View();
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }      
        }

        //
        // POST: /Medication/Create
        [HttpPost]
        public ActionResult Create(Medication_Table medication)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Medication_Table.Add(medication);
                    db.SaveChanges();
                    TempData["notice"] = "Medication added Successfully:\n Medication Name: " + medication.medication_name;
                    return RedirectToAction("Index");
                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }

            return View(medication);
        }

        //
        // GET: /Medication/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Medication_Table medication = db.Medication_Table.Find(id);
                if (medication == null)
                {
                    return HttpNotFound();
                }

                return View(medication);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }    
        }

        //
        // POST: /Medication/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var medicationToUpdate = db.Medication_Table.Find(id);
            if (TryUpdateModel(medicationToUpdate, "",
                new string[] { "medication_Id", "medication_name", "indications", "warnings", "mg" }))
            {
                try
                {
                    db.SaveChanges();
                    TempData["notice"] = "Medication Edited Successfully:\n Medication Name: " + medicationToUpdate.medication_name;

                    return RedirectToAction("Index");
                }
                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
            }

            return View(medicationToUpdate);
        }

        //
        // GET: /Medication/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Medication_Table medication = db.Medication_Table.Find(id);
                if (medication == null)
                {
                    return HttpNotFound();
                }
                return View(medication);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }      
        }

        //
        // POST: /Medication/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, FormCollection collection)
        {
            Medication_Table medication = db.Medication_Table.Find(id);
            db.Medication_Table.Remove(medication);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
