﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using SVU_ISE_F15_PR1_PRO6.Models;


namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class BandAidController : Controller
    {
        // GET: BandAid
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /Post/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            ViewBag.CurrentSort = sortOrder;
            ViewBag.publish_Date = String.IsNullOrEmpty(sortOrder) ? "date" : "";
            ViewBag.publisher = sortOrder == "pub" ? "_pub" : "pub";

            if (searchString != null)
            {
                pagePos = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;
            int pageNumber = (pagePos ?? 1);

            if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("Employee_"))
            {
                var aid = from p in db.BandAid_Table
                          select p;
                if (!String.IsNullOrEmpty(searchString))
                {
                    aid = aid.Where(s => s.title.Contains(searchString)
                        || s.article.Contains(searchString)); 
                       
                       
                }

                switch (sortOrder)
                {
                    case "date":
                        aid = aid.OrderByDescending(s => s.publish_Date);
                        break;
                    case "pup":
                        aid = aid.OrderBy(s => s.publisher);
                        break;
                    case "_pub":
                        aid = aid.OrderByDescending(s => s.publisher);
                        break;
                    default:
                        aid = aid.OrderBy(s => s.publish_Date);
                        break;
                }
                return View(aid.ToList().ToPagedList(pageNumber, 8));
            }
            else if (profileData.username.StartsWith("dr_"))
            {

                var _aid = from p in db.BandAid_Table
                            where p.publisher == profileData.username
                            select p;
                if (!String.IsNullOrEmpty(searchString))
                {
                    _aid = _aid.Where(s => s.title.Contains(searchString)
                        || s.article.Contains(searchString));
                }

                switch (sortOrder)
                {
                    case "date":
                        _aid = _aid.OrderByDescending(s => s.publish_Date);
                        break;
                    case "_pub":
                        _aid = _aid.OrderBy(s => s.publisher);
                        break;
                    case "pub":
                        _aid = _aid.OrderByDescending(s => s.publisher);
                        break;
                    default:
                        _aid = _aid.OrderBy(s => s.publish_Date);
                        break;
                }
                return View(_aid.ToList().ToPagedList(pageNumber, 8));
            }
            else
            {
                return RedirectToAction("accessBlock", "Home");
            }
        }

        public ActionResult ArticlsView(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            ViewBag.CurrentSort = sortOrder;
            ViewBag.publish_Date = String.IsNullOrEmpty(sortOrder) ? "date" : "";

            if (searchString != null)
            {
                pagePos = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            var aid = from p in db.BandAid_Table.OrderByDescending(t => t.publish_Date).ThenByDescending(c => c.publish_Time)
                      select p;
            if (!String.IsNullOrEmpty(searchString))
            {
                aid = aid.Where(s => s.title.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "date":
                    aid = aid.OrderByDescending(s => s.publish_Date);
                    break;
                default:
                    aid = aid.OrderBy(s => s.publish_Date);
                    break;
            }
            int pageNumber = (pagePos ?? 1);
            return View(aid.ToList().ToPagedList(pageNumber, 8));
        }

        //
        // GET: /Post/Details/5
        public ActionResult Details(int id)
        {
            return View(db.BandAid_Table.Find(id));
        }


        //
        // GET: /Post/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                return View();
            }
        }

        //
        // POST: /Post/Create
        [HttpPost]
        public ActionResult Create(BandAid_Table aid, HttpPostedFileBase file)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            try
            {
                if (ModelState.IsValid)
                {
                    var today = DateTime.Today;
                    var currentTime = DateTime.Now.TimeOfDay;

                    aid.publisher = profileData.username;
                    aid.publish_Date = today;
                    aid.publish_Time = currentTime;
                    if (file != null)
                    {
                        file.SaveAs(HttpContext.Server.MapPath("~/Images/")
                                                              + file.FileName);
                        aid.ImagePath = file.FileName;
                    }

                    db.BandAid_Table.Add(aid);
                    db.SaveChanges();
                    TempData["notice"] = "Article Title: " + aid.title + "And Id: " + aid.aid_Id + "Added Successfully..";
                    return RedirectToAction("Index");

                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            return View();
        }

        //
        // GET: /Post/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                BandAid_Table aid = db.BandAid_Table.Find(id);
                if (aid == null)
                {
                    return HttpNotFound();
                }
                return View(aid);
            }
        }

        //
        // POST: /Post/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int? id, BandAid_Table aidToUpdate)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            aidToUpdate = db.BandAid_Table.Find(id);
            if (TryUpdateModel(aidToUpdate, "",
                new string[] {"aid_Id","publisher","title","article",
                    "publish_Date","publish_Time","edit_Date","edit_Time" }))
            {
                try
                {
                    db.SaveChanges();
                    TempData["notice"] = "Article Title: " + aidToUpdate.title + "And Id: " + aidToUpdate.aid_Id + "Edited Successfully..";
                    return RedirectToAction("Index");
                }

                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");

                }
            }
            return View(aidToUpdate);
        }

        //
        // GET: /Post/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                BandAid_Table aid = db.BandAid_Table.Find(id);
                if (aid == null)
                {
                    return HttpNotFound();
                }
                return View(aid);
            }
        }

        //
        // POST: /Post/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int? id, BandAid_Table aid)
        {
            aid = db.BandAid_Table.Find(id);
            db.BandAid_Table.Remove(aid);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

     
     
    }
}