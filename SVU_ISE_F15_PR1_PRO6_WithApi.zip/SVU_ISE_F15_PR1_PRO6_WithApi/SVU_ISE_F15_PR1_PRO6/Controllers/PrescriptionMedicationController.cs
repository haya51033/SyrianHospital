﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;
using System.Web.Security;
using AttributeRouting.Web.Http;
using System.IO;




namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class PrescriptionMedicationController : Controller
    {

        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /PrescriptionMedication/
        public ActionResult Index(int? pagePos, string sortOrder, int? currentFilter, int? searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.prescription_Id = String.IsNullOrEmpty(sortOrder) ? "prs_id" : "";
                ViewBag.medication_Id = sortOrder == "med" ? "med_id" : "med";
                ViewBag.start_date = sortOrder == "Date" ? "start_d" : "Date";
                ViewBag.end_date = sortOrder == "end" ? "end_d" : "end";

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var pm = from p_m in db.PrescriptionMedication_Table
                         select p_m;

                if (searchString != null)
                {
                    pm = pm.Where(s => s.prescription_Id == searchString);
                }
                switch (sortOrder)
                {
                    case "prs_id":
                        pm = pm.OrderByDescending(s => s.prescription_Id);
                        break;
                    case "Date":
                        pm = pm.OrderBy(s => s.start_date);
                        break;
                    case "start_d":
                        pm = pm.OrderByDescending(s => s.start_date);
                        break;
                    case "end":
                        pm = pm.OrderBy(s => s.end_date);
                        break;
                    case "end_d":
                        pm = pm.OrderByDescending(s => s.end_date);
                        break;
                    case "med":
                        pm = pm.OrderBy(s => s.Medication_Table.medication_name);
                        break;
                    case "med_id":
                        pm = pm.OrderByDescending(s => s.Medication_Table.medication_name);
                        break;
                    default:
                        pm = pm.OrderBy(s => s.prescription_Id);
                        break;
                }
                int pageNumber = (pagePos ?? 1);
                if (profileData.username.StartsWith("dr_"))
                {
                    
                    var doctor_PrescriptionMedication_list = from p in db.PrescriptionMedication_Table
                                                             join m in db.Medication_Table on p.medication_Id equals m.medication_Id
                                                             join pr in db.Prescription_Table on p.prescription_Id equals pr.prescription_Id
                                                             where pr.dr_Id == profileData.dr_Id 
                                                             select p;
                      if (searchString != null)
                {
                    doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.Where(s => s.prescription_Id == searchString);
                }
                      switch (sortOrder)
                      {
                          case "prs_id":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderByDescending(s => s.prescription_Id);
                              break;
                          case "Date":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderBy(s => s.start_date);
                              break;
                          case "start_d":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderByDescending(s => s.start_date);
                              break;
                          case "end":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderBy(s => s.end_date);
                              break;
                          case "end_d":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderByDescending(s => s.end_date);
                              break;
                          case "med":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderBy(s => s.Medication_Table.medication_name);
                              break;
                          case "med_id":
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderByDescending(s => s.Medication_Table.medication_name);
                              break;
                          default:
                              doctor_PrescriptionMedication_list = doctor_PrescriptionMedication_list.OrderBy(s => s.prescription_Id);
                              break;
                      }
                    return View(doctor_PrescriptionMedication_list.ToList().ToPagedList(pageNumber, 10));
                }
                else
                {
                    return View(pm.ToList().ToPagedList(pageNumber, 10));

                }
            }
            
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // GET: /PrescriptionMedication/Details/5
        public ActionResult Details(int? medication_Id, int? prescription_Id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                PrescriptionMedication_Table pm = db.PrescriptionMedication_Table.Find(medication_Id, prescription_Id);
                if (pm == null)
                {
                    return HttpNotFound();
                }
                return View(pm);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // GET: /PrescriptionMedication/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                PopulateMedicationDropDownList();
                PopulatePrescriptionDropDownList();
                return View();
            }
            else 
            {
                return RedirectToAction("accessBlock1", "Home");
            }

        }

        //
        // POST: /PrescriptionMedication/Create
        [HttpPost]
        public ActionResult Create(PrescriptionMedication_Table pm)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // if primary key is exist
                    if (Check(pm.prescription_Id, pm.medication_Id))
                    {
                        ModelState.AddModelError("", "The patient is alredy have this medication");
                    }
                    
                    else
                    {
                        db.PrescriptionMedication_Table.Add(pm);
                        db.SaveChanges();
                        TempData["notice"] = "Successfully Assign Medication: "+pm.medication_Id+ ", To Prescription Id: " + pm.prescription_Id;
                        return RedirectToAction("Index");
                    }

                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
            PopulateMedicationDropDownList(pm.medication_Id);
            PopulatePrescriptionDropDownList(pm.prescription_Id);

            return View(pm);
        }

        //
        // GET: /PrescriptionMedication/Edit/5
        public ActionResult Edit(int? medication_Id, int? prescription_Id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                if ((prescription_Id == null) || (medication_Id == null))
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                PrescriptionMedication_Table pm = db.PrescriptionMedication_Table.Find(medication_Id, prescription_Id);
                if (pm == null)
                {
                    return HttpNotFound();
                }
                PopulateMedicationDropDownList(pm.medication_Id);
                PopulatePrescriptionDropDownList(pm.prescription_Id);
                return View(pm);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // POST: /PrescriptionMedication/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(PrescriptionMedication_Table pm)
        {
            if (ModelState.IsValid)
            {
                // if primary key is exist
                if (Check(pm.prescription_Id, pm.medication_Id))
                {
                    ModelState.AddModelError("", "The patient is alredy have this medication");
                }
                db.Entry(pm).State = EntityState.Modified;
                db.SaveChanges();
                TempData["notice"] = "Successfully Edited Prescription Medication:\n Medication Name: " + pm.Medication_Table.medication_name + "To Prescription Id: " + pm.prescription_Id;

                return RedirectToAction("Index");
            }
            PopulateMedicationDropDownList();
            PopulatePrescriptionDropDownList();
            return View(pm);

        }

        //
        // GET: /PrescriptionMedication/Delete/5
        public ActionResult Delete(int? medication_Id, int? prescription_Id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;
            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                if ((prescription_Id == null) || (medication_Id == null))
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                PrescriptionMedication_Table pm = db.PrescriptionMedication_Table.Find(medication_Id, prescription_Id);
                if (pm == null)
                {
                    return HttpNotFound();
                }

                return View(pm);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // POST: /PrescriptionMedication/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeletePost(int? medication_Id, int? prescription_Id)
        {
            PrescriptionMedication_Table pm = db.PrescriptionMedication_Table.Find(medication_Id, prescription_Id);
            db.PrescriptionMedication_Table.Remove(pm);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        private void PopulateMedicationDropDownList(object selectedmedication = null)
        {
            var medicationQuery = from d in db.Medication_Table
                                  orderby d.medication_name
                                  select d;
            ViewBag.medication_Id = new SelectList(medicationQuery, "medication_Id", "medication_name",selectedmedication);
        }

        private void PopulatePrescriptionDropDownList(object selectedprescription = null)
        {
        var profileData = this.Session["UserProfile"] as Users_Table;

        if (profileData.username.StartsWith("Admin_")) {
            var prescriptionQuery = from d in db.Prescription_Table
                                    orderby d.prescription_Id
                                    select d;
            ViewBag.prescription_Id = new SelectList(prescriptionQuery, "prescription_Id", "prescription_Id", selectedprescription);

        }
        if (profileData.username.StartsWith("dr_")) {
            var prescriptionQuery = from d in db.Prescription_Table
                                    where d.dr_Id == profileData.dr_Id
                                    orderby d.prescription_Id
                                    select d;
            ViewBag.prescription_Id = new SelectList(prescriptionQuery, "prescription_Id", "prescription_Id", selectedprescription);
        }


            
        }
        public bool Check(int key1, int key2)
        {
            return db.PrescriptionMedication_Table.Any(x => x.prescription_Id == key1 && x.medication_Id == key2);
        }
        public ActionResult doctorList()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            var doctor_PrescriptionMedication_list = from p in db.PrescriptionMedication_Table
                                       join m in db.Medication_Table on p.medication_Id equals m.medication_Id
                                       join pr in db.Prescription_Table on p.prescription_Id equals pr.prescription_Id
                                       where pr.dr_Id == profileData.dr_Id
                                       select p;
            return View(doctor_PrescriptionMedication_list);
        }

        
      
    }
}
