﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.Http.ValueProviders.Providers;
using PagedList;


namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class FollowUpController : Controller
    {
        HospitalDatabaseEntities1 db = new HospitalDatabaseEntities1();
        //
        // GET: /FollowUp/
        public ActionResult Index(int? pagePos, string sortOrder, string currentFilter, string searchString)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else if ((profileData.username.StartsWith("Admin_")) || (profileData.username.StartsWith("dr_") || (profileData.username.StartsWith("Employee_"))))
            {
                ViewBag.CurrentSort = sortOrder;
                ViewBag.date = String.IsNullOrEmpty(sortOrder) ? "date" : "";
                ViewBag.originator_type = sortOrder == "o_t" ? "o" : "o_t";
                ViewBag.originatorUsername = sortOrder == "o_u" ? "o_" : "o_u";

                if (searchString != null)
                {
                    pagePos = 1;
                }
                else
                {
                    searchString = currentFilter;
                }

                ViewBag.CurrentFilter = searchString;

                var follow = from s in db.FollowUp_Table
                             select s;
                if (!String.IsNullOrEmpty(searchString))
                {
                    follow = follow.Where(d => d.Patient_Table1.p_l_name.Contains(searchString));
                }

                switch (sortOrder)
                {
                    case "date":
                        follow = follow.OrderBy(s => s.date);
                        break;
                    case "o_t":
                        follow = follow.OrderByDescending(s => s.originator_type);
                        break;
                    case "o":
                        follow = follow.OrderBy(s => s.originator_type);
                        break;
                    case "o_u":
                        follow = follow.OrderByDescending(s => s.originatorUsername);
                        break;
                    case "o_":
                        follow = follow.OrderBy(s => s.originatorUsername);
                        break;
                    default:
                        follow = follow.OrderByDescending(s => s.date);
                        break;
                }
                int pageNumber = (pagePos ?? 1);
                if (profileData.username.StartsWith("dr_"))
                {
                    var doctor_followUp_list = from p in db.FollowUp_Table
                                               join e in db.EditPatientFile_Table on p.p_Id equals e.p_Id
                                               where  e.dr_Id == profileData.dr_Id 
                                               select p;
                    if (!String.IsNullOrEmpty(searchString))
                    {
                        doctor_followUp_list = doctor_followUp_list.Where(d => d.Patient_Table1.p_l_name.Contains(searchString));
                    }

                    switch (sortOrder)
                    {
                        case "date":
                            doctor_followUp_list = doctor_followUp_list.OrderBy(s => s.date);
                            break;
                        case "o_t":
                            doctor_followUp_list = doctor_followUp_list.OrderByDescending(s => s.originator_type);
                            break;
                        case "o":
                            doctor_followUp_list = doctor_followUp_list.OrderBy(s => s.originator_type);
                            break;
                        case "o_u":
                            doctor_followUp_list = doctor_followUp_list.OrderByDescending(s => s.originatorUsername);
                            break;
                        case "o_":
                            doctor_followUp_list = doctor_followUp_list.OrderBy(s => s.originatorUsername);
                            break;
                        default:
                            doctor_followUp_list = doctor_followUp_list.OrderByDescending(s => s.date);
                            break;
                    }
                    return View(doctor_followUp_list.ToList().ToPagedList(pageNumber, 10));
                }
                else {
                    return View(follow.ToList().ToPagedList(pageNumber, 10));
                }
            }     
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }

        }

        //
        // GET: /FollowUp/Details/5
        public ActionResult Details(int id)
        {
             var profileData = this.Session["UserProfile"] as Users_Table;

             if (profileData == null)
             {
                 return RedirectToAction("accessBlock", "Home");
             }
             else
             {
                 return View(db.FollowUp_Table.Find(id));
             }
        }

        //
        // GET: /FollowUp/Create
        public ActionResult Create()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }
            else {
                if (profileData.username.StartsWith("Admin_"))
                {
                    PopulatePatientDropDownList();
                    PopulateDoctorsDropDownList();
                    FollowUp_Table f = new FollowUp_Table();
                    f.originatorUsername = profileData.username;
                    f.originator_type = "Admin";
                    return View(f);
                }
                if (profileData.username.StartsWith("dr_"))
                {
                    PopulatePatientDropDownList();
                    FollowUp_Table f = new FollowUp_Table();
                    f.originatorUsername = profileData.username;
                    f.originator_type = "Doctor";
                    return View(f);
                }
                return View();
            }     
        }

        //
        // POST: /FollowUp/Create
        [HttpPost]
        public ActionResult Create(FollowUp_Table followUp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (followUp.originator_type == "Patient")
                    {
                       followUp.originatorUsername = null;
                    }            
                    db.FollowUp_Table.Add(followUp);
                    db.SaveChanges();
                    TempData["notice"] = "Follow Up Successfully added for Patient:\n Id: " + followUp.p_Id;
                    return RedirectToAction("Index");
                }
            }
            catch (RetryLimitExceededException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            }
             PopulatePatientDropDownList(followUp.p_Id);

           PopulateDoctorsDropDownList(followUp.originatorUsername);
           PopulatePatientDropDownList(followUp.p_Id);
            return View(followUp);
        }

        //
        // GET: /FollowUp/Edit/5
        public ActionResult Edit(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }

            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                FollowUp_Table follow = db.FollowUp_Table.Find(id);
                if (follow == null)
                {
                    return HttpNotFound();
                }
                PopulatePatientDropDownList(follow.p_Id);

                return View(follow);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // POST: /FollowUp/Edit/5
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var followUpToUpdate = db.FollowUp_Table.Find(id);
            if (TryUpdateModel(followUpToUpdate, "",
                new string[] { "followUp_Id", "date", "at_time","temperature", "weight", "high_blood_pressure",
                               "low_blood_pressure","blood_sugar","pregnant","p_Id"}))
            {
                try
                {
                    db.SaveChanges();
                    TempData["notice"] = "Follow Up Successfully Edited for Patient:\n Id: " + followUpToUpdate.p_Id;
                    return RedirectToAction("Index");
                }
                catch (RetryLimitExceededException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
            }
            PopulatePatientDropDownList();
            return View(followUpToUpdate);
        }
    

        //
        // GET: /FollowUp/Delete/5
        public ActionResult Delete(int? id)
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            if (profileData == null)
            {
                return RedirectToAction("accessBlock", "Home");
            }

            else if (profileData.username.StartsWith("Admin_") || profileData.username.StartsWith("dr_"))
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                FollowUp_Table follow = db.FollowUp_Table.Find(id);
                if (follow == null)
                {
                    return HttpNotFound();
                }
                return View(follow);
            }
            else
            {
                return RedirectToAction("accessBlock1", "Home");
            }
        }

        //
        // POST: /FollowUp/Delete/5
       [HttpPost, ActionName("Delete")]
       [ValidateAntiForgeryToken]
        public ActionResult DeletePost(int? id)
        {
            FollowUp_Table follow = db.FollowUp_Table.Find(id);
            db.FollowUp_Table.Remove(follow);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        
        private void PopulatePatientDropDownList(object selectedpatient = null)
        {
         var profileData = this.Session["UserProfile"] as Users_Table;
         if (profileData.username.StartsWith("dr_"))
         {
             var patientQuery = from d in db.Patient_Table
                                join e in db.EditPatientFile_Table on d.p_Id equals e.p_Id
                                where e.dr_Id == profileData.dr_Id
                                orderby d.p_username
                                select d;
             ViewBag.p_Id = new SelectList(patientQuery, "p_Id", "p_username", selectedpatient);

         }
         else
         {
             var patientQuery = from d in db.Patient_Table
                                orderby d.p_username
                                select d;
             ViewBag.p_Id = new SelectList(patientQuery, "p_Id", "p_username", selectedpatient);

         }
           
        }

        private void PopulateDoctorsDropDownList(object selecteddoctor = null)
        {
            var doctorQuery = from d in db.Doctors_Table
                              orderby d.dr_Id
                              select d;
            ViewBag.dr_Id = new SelectList(doctorQuery, "dr_Id", "dr_username", selecteddoctor);
        }

        public ActionResult doctorList()
        {
            var profileData = this.Session["UserProfile"] as Users_Table;

            var doctor_followUp_list = from p in db.FollowUp_Table
                                        join dr in db.Doctors_Table on p.originatorUsername equals dr.dr_username
                                        where dr.dr_Id == profileData.dr_Id
                                        select p;
            return View(doctor_followUp_list);
        }

      
    }
}
