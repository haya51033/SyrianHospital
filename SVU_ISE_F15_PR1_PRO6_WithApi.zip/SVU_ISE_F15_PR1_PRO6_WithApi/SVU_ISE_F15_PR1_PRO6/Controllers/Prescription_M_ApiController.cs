﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using System;
using SVU_ISE_F15_PR1_PRO6.Models;

namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class Prescriptions_M_ApiController : ApiController
    {
        [RoutePrefix("api/prescriptions")]
        public class P_M_ApiController : ApiController
        {
            [HttpGet]
            [Route("{patientId}")] //http://localhost:2917/api/prescriptions/29
            public IHttpActionResult Get(int patientId)
            {            
                if (patientId == 0) return BadRequest("Please provide parameters");
                using (var context = new HospitalDatabaseEntities1())
                {
                    var medicationList = new List<PrescriptionMedicationViewModel>();                  
                    DateTime today = DateTime.Now;
                    
                       var medications = from p_m in context.PrescriptionMedication_Table
                                         join p in context.Prescription_Table on p_m.prescription_Id equals p.prescription_Id
                                         where p.p_Id == patientId && (p_m.end_date >= today) && (p_m.start_date <= today)
                                         select p_m;
                                      
                        if (!medications.Any()) return Ok();
                        foreach (var medication in medications)
                        {
                            var medicationName = context.Medication_Table.Single(m => m.medication_Id == medication.medication_Id).medication_name;
                            medicationList.Add(ConvertTableEntryToViewModel(medication, medicationName));
                        }
          
                    return Ok(medicationList);
                }
            }

            

            private static PrescriptionMedicationViewModel ConvertTableEntryToViewModel(PrescriptionMedication_Table entry, string medicationName)
            {
                
                return new PrescriptionMedicationViewModel
                {
                    Prescription_Id = entry.prescription_Id,
                    Medication_Id = entry.medication_Id,
                    Medication = medicationName,
                    StartDate = string.Format("{0:d}", entry.start_date),
                    EndtDate = string.Format("{0:d}", entry.end_date),
                    Amount = entry.amount,
                    Notes = entry.notes,
                    Unit = entry.unit,
                    TimesPerDay = entry.TimesPerDay
                };
            }

        }
    }
}