﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using SVU_ISE_F15_PR1_PRO6.Models;


namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class MyDrPhoneController : ApiController
    {
        [RoutePrefix("api/myDrPhone")]
        public class drphoneAPIController : ApiController
        {
            [HttpGet]
            [Route("{patientId}")]
            public IHttpActionResult Get(int patientId)
            {
                using (var context = new HospitalDatabaseEntities1())
                {
                    var drList = new List<MyDrPhoneModels>();

                    var doctor = from d in context.Doctors_Table
                                 join s in context.EditPatientFile_Table on d.dr_Id equals s.dr_Id
                                 join p in context.Patient_Table on s.p_Id equals p.p_Id
                                 where p.p_Id == patientId
                                 select d;

                    if (!doctor.Any()) return Ok();
                    foreach (var dr in doctor)
                    {
                        drList.Add(ConvertTableEntryToViewModel(dr));
                    }

                    return Ok(drList);
                }
            }
        }

        private static MyDrPhoneModels ConvertTableEntryToViewModel(Doctors_Table entry)
        {
            return new MyDrPhoneModels
            {
                FirstName = entry.dr_f_name,
                LastName = entry.dr_l_name,
                Specialization = entry.dr_specialization,
                Phone1 = entry.dr_phone1,
                Phone2 = entry.dr_phone2,
                Email = entry.dr_email
               
            };
        }
    }
}
