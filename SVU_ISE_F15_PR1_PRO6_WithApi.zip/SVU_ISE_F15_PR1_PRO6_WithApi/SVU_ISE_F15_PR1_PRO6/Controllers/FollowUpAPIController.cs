﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using SVU_ISE_F15_PR1_PRO6.Models;


namespace SVU_ISE_F15_PR1_PRO6.Controllers
{
    public class FollowUpAPIController : ApiController
    {
        [RoutePrefix("api/followUpapi")]
        public class FUpAPIController : ApiController
        {
            [HttpGet]
            [Route("{patientId}")]
            public IHttpActionResult Get(int patientId)
            {
                using (var context = new HospitalDatabaseEntities1())
                {
                    var followList = new List<FollowUpViewModel>();

                    var follow = from p in context.FollowUp_Table
                                 where p.p_Id == patientId
                                 select p;
                    if (!follow.Any()) return Ok();
                    foreach (var f in follow)
                    {
                        followList.Add(ConvertTableEntryToViewModel(f));
                    }

                    return Ok(followList);
                }
            }
        }

            [HttpPost]
            public IHttpActionResult Post([FromBody] FollowUp_Table model)
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                using (var context = new HospitalDatabaseEntities1())
                {
                    var savedRecord = context.FollowUp_Table.Add(model);
                    context.SaveChanges();
                    return Created(new Uri(Url.Link("Default", new { id = savedRecord.followUp_Id })), ConvertTableEntryToViewModel(savedRecord));
                }
            }


       

            private static FollowUpViewModel ConvertTableEntryToViewModel(FollowUp_Table entry)
            {
                //string a = entry.at_time.ToString();
                //string[] separatingChars = { "%3A" };
                //string[] b = a.Split(separatingChars, System.StringSplitOptions.RemoveEmptyEntries);
                //string c = b[0] + ":" + b[1] + ":" + b[2];
                return new FollowUpViewModel
                {
                    Id = entry.followUp_Id,
                    date = string.Format("{0:d}", entry.date),
                    at_time = string.Format("{0:hh\\:mm\\:ss}", entry.at_time),
                    temperature = entry.temperature,
                    weight = entry.weight,
                    high_blood_pressure = entry.high_blood_pressure,
                    low_blood_pressure = entry.low_blood_pressure,
                    blood_sugar = entry.blood_sugar,
                    pregnant = entry.pregnant,
                    p_Id = entry.p_Id,
                    originator_type = entry.originator_type,
                    originatorUsername = entry.originatorUsername
                };
            }
        }
    }
