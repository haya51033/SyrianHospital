﻿namespace SVU_ISE_F15_PR1_PRO6.Models
{
    public class PatientLoginRequestModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int PatientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
    }
}