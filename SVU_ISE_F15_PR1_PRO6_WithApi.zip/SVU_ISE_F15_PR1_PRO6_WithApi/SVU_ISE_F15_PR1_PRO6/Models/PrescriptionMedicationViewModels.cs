﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace SVU_ISE_F15_PR1_PRO6.Models
{
    public class PrescriptionMedicationViewModel
    {
        public int Prescription_Id { get; set; }
        public int Medication_Id { get; set; }
        public string Medication { get; set; }
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}",
        //       ApplyFormatInEditMode = true)]
        public string StartDate { get; set; }
       //[DataType(DataType.Date)]
       //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}",
       //       ApplyFormatInEditMode = true)]
        public string EndtDate { get; set; }
        public decimal? Amount { get; set; }
        public string Notes { get; set; }
        public int? TimesPerDay { get; set; }

        public string Unit { get; set; }
    }
}