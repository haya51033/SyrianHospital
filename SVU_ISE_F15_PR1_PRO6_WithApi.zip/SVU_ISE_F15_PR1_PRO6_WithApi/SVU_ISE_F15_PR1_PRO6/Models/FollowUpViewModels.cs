﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SVU_ISE_F15_PR1_PRO6.Models
{
    public class FollowUpViewModel
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Date")]
        [Required(ErrorMessage = "{0} is required")]
        public string date { get; set; }

        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:hh:mm tt}")]
        //[DataType(DataType.Time)]
        public string at_time { get; set; }
        public int? temperature { get; set; }
        public int? weight { get; set; }
        public decimal? high_blood_pressure { get; set; }
        public decimal? low_blood_pressure { get; set; }
        public decimal? blood_sugar { get; set; }
        public bool? pregnant { get; set; }
        public int? p_Id { get; set; }
        public string originator_type { get; set; }
        public string originatorUsername { get; set; }
    }
}