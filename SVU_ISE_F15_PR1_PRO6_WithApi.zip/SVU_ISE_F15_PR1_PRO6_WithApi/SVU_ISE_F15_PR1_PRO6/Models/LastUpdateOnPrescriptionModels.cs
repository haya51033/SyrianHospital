﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SVU_ISE_F15_PR1_PRO6.Models
{
    public class LastUpdateOnPrescriptionModels
    {
        //public int prescriptionId { get; set; }
        public string prescriptionDate { get; set; }
        public int? patientId { get; set; }
    }
}