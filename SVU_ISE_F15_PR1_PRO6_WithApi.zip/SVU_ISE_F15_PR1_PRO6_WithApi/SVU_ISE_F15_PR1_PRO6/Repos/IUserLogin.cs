﻿using System.Linq;



namespace SVU_ISE_F15_PR1_PRO6.Repos
{
    internal interface IUserLogin
    {
        int LogIn(string username, string password);
    }

    public class UserLogin : IUserLogin
    {
        public int LogIn(string username, string password)
        {
            using (var context = new HospitalDatabaseEntities1())
            {
                var user = context.Users_Table.FirstOrDefault(u => u.username == username && u.password == password);
                if (user == null) return 0;
                return user.p_Id == null ? 0 : user.p_Id.Value;
            }
        }
    }
}
